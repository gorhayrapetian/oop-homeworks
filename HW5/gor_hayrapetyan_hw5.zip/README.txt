Author of the homework: Gor Hayrapetyan
AUA ID: HA5402752

The 4th problem files are PhoneNumberDemo and PhoneNumber, you can input the whole phone numbers of the both sides and the duration of the call.
Be carefull to run the PhoneNumberDemo file.