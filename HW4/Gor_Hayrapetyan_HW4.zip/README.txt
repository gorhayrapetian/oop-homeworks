Author of the homework: Gor Hayrapetyan
AUA ID: HA5402752

references

https://stackoverflow.com/questions/12775133/create-a-method-that-can-count-negative-numbers-in-an-array

https://stackoverflow.com/questions/34635925/java-parse-array-to-positive-and-negative-array