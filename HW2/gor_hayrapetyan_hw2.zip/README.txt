Author of the homework: Gor Hayrapetyan
AUA ID: HA5402752