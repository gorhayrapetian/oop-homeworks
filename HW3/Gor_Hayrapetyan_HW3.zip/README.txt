Author of the homework: Gor Hayrapetyan
AUA ID: AUA ID: HA5402752

Problem 1
If you input the date of birth unordered, the program will crash and won't work, so please follow the example (e.g., 14 July 2007).

Problem 4
The code works only with precise input, like in the example (e.g., breakfast 400). Please input the exact input so the program works. 

How to italicized the String in java:
https://stackoverflow.com/questions/30310147/how-to-print-an-string-variable-as-italicized-text

How to find lowest number messes up when inputting negative numbers:
https://stackoverflow.com/questions/35737048/java-find-lowest-number-messes-up-when-inputting-negative-numbers