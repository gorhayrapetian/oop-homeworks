// In mathematical terms, the expression 10 - 100.0 / 600 - 100.0 / 600 - 100.0 / 600 equals 9.5.
// However, due to floating-point precision in computer arithmetic, the actual result may not be exactly 9.5.
// The following Java code demonstrates the calculation and prints the result, which may have a small rounding error.
public class Problem2 {
    public static void main(String[] args) {
        double a = 10 - 100.0 / 600 - 100.0 / 600 - 100.0 / 600;
        System.out.println(a);
    }
}
