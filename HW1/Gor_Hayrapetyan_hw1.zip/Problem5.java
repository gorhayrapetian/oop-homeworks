public class Problem5 {
    public static void main(String[] args) {
        // Coordinates of the quadrilateral vertices
        int x1 = -3, y1 = 1;
        int x2 = -1, y2 = 4;
        int x3 = 3, y3 = 2;
        int x4 = 1, y4 = -2;

        // Calculating the length of each side
        double length1 = getLength(x1, x2, y1, y2);
        double length2 = getLength(x2, x3, y2, y3);
        double length3 = getLength(x3, x4, y3, y4);
        double length4 = getLength(x4, x1, y4, y1);

        // Calculating the perimeter and area of the quadrilateral
        double perimeter = getPerimeter(length1, length2, length3, length4);
        double area = getArea(length1, length2, length3, length4);

        // printing the results
        System.out.println("Vertices A: (" + x1 + "," + y1 + "), B: (" + x2 + "," + y2 + "), C: (" + x3 + "," + y3 + "), D: (" + x4 + "," + y4 + ")");
        System.out.println("Perimeter: " + perimeter);
        System.out.println("Area: " + area);
    }

    // Calculate the length of a side using the distance formula
    private static double getLength(int x1, int x2, int y1, int y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }

    // Calculate the perimeter of the quadrilateral
    private static double getPerimeter(double length1, double length2, double length3, double length4) {
        return length1 + length2 + length3 + length4;
    }

    // Calculate the area of the quadrilateral using Heron's formula
    private static double getArea(double length1, double length2, double length3, double length4) {
        // Calculate the semi-perimeter
        double halfParameter = (length1 + length2 + length3 + length4) / 2;
        // Calculate and return the area using Heron's formula
        return Math.sqrt(halfParameter * (halfParameter - length1) * (halfParameter - length2) * (halfParameter - length3) * (halfParameter - length4));
    }
}
