public class Problem4 {
    public static void main(String[] args) {
        // Declaring the variable
        int n = 200;

        // Counting the change
        int hundreds = n / 100;
        n %= 100;

        int fifties = n / 50;
        n %= 50;

        int twenties = n / 20;
        n %= 20;

        int tens = n / 10;
        n %= 10;

        int fives = n / 5;
        n %= 5;

        int ones = n;

        // Printing the result
        System.out.println("Hundreds: " + hundreds);
        System.out.println("Fifties: " + fifties);
        System.out.println("Twenties: " + twenties);
        System.out.println("Tens: " + tens);
        System.out.println("Fives: " + fives);
        System.out.println("Ones: " + ones);
    }
}
