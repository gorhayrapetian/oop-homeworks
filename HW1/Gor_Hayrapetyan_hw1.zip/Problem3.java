public class Problem3 {
    public static void main(String[] args) {
        // Declare the AUA ID
        String auaID = "HA5402762";
        // take the numerical part which is String
        String numericalPart = auaID.substring(2);
        // Convert to integer
        int numericalValue = Integer.parseInt(numericalPart);
        // Checking if numerical value is divisible by 5
        boolean isDivisibleBy5 = numericalValue % 5 == 0;
        // Printing the result
        System.out.println("AUA ID: HA" + numericalPart);
        System.out.println(isDivisibleBy5);
    }
}